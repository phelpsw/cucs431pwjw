package aws_owl;
import org.w3c.dom.*;

public class QueryTool {

		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
                /*
		AwsHandler ah = new AwsHandler();
		
		TripleLoader t = new TripleLoader();
		Document doc = ah.query("madonna", AwsHandler.DVD);
		t.Load(doc);
		*/
	}

}
